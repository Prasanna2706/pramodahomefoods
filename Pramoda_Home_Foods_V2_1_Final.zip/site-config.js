window.PRAMODA_CONFIG = {
  whatsapp: "916369304437",
  address: "NEST Bonsai, Ottiambakkam Main Rd, Ottiambakkam, Chennai, Tamil Nadu 600130",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=NEST+Bonsai%2C+Ottiambakkam+Main+Rd%2C+Ottiambakkam%2C+Chennai%2C+Tamil+Nadu+600130",
  mapEmbedUrl: "https://www.google.com/maps?q=NEST%20Bonsai%2C%20Ottiambakkam%20Main%20Rd%2C%20Ottiambakkam%2C%20Chennai%2C%20Tamil%20Nadu%20600130&output=embed"
};