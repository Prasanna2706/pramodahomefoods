window.PRAmODA_MENU = [
 {icon:"🌅",title:"Breakfast",items:[
  {name:"Idly (4) with Kara Chutney & Sambar",price:"₹60"},
  {name:"Pongal with Sambar",price:"₹60"},
  {name:"Vada",price:"₹10"},
  {name:"Dosa",price:"₹60"}
 ]},
 {icon:"🍚",title:"Lunch — Veg",items:[
  {name:"Meals 1 — Rice, Sambar, Rasam, Poriyal, Appalam",price:"₹125"},
  {name:"Meals 2 — Rice, Vathakuzhambu, Buttermilk, Kootu, Appalam",price:"₹125"},
  {name:"Gravy / Sides Combo",price:"₹75"}
 ]},
 {icon:"🍗",title:"Lunch — Non-Veg",items:[
  {name:"Rice & Chicken Curry",price:"₹120"},
  {name:"Rice & Mutton Curry",price:"₹150"},
  {name:"Rice & Egg Curry",price:"₹100"},
  {name:"Rice & Prawn Curry",price:"₹150"},
  {name:"Rice & Fish Curry",price:"₹130"}
 ]},
 {icon:"🌙",title:"Dinner",items:[
  {name:"Chapati",price:"₹80"},
  {name:"Upma",price:"₹60"},
  {name:"Aapam",price:"₹60"}
 ]}
];